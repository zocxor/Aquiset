# AQUISET v5.3.1 — Format fix, corrected (matches CI exactly)

## What was wrong with v5.3

v5.3 was formatted with Dart 3.13.7 (the same version CI uses) — but WITHOUT the
project's package config. Without it, the formatter cannot resolve the project's
`analysis_options.yaml` include (`package:flutter_lints/flutter.yaml`) and cannot
see the project's language version (3.7), so it falls back to default settings.

CI runs `flutter pub get` BEFORE the format check, so its formatter DOES resolve
the include and the language version — and its output differs from the fallback
output on exactly 18 files. That is why CI #3 still listed the same 18 files
even though the v5.3 files were on disk and in the commit: v5.3's files were
formatted with the wrong settings, so to CI they still needed formatting.

Proof: with a package config present, the same Dart 3.13.7 flags the v5.3 files
as `Formatted 30 files (18 changed)` — the exact same 18 files CI listed.

## What v5.3.1 is

The same 30 `.dart` files, reformatted with Dart 3.13.7 WITH the package config
resolved (flutter_lints 5.0.0 + lints 5.1.1, language version 3.7) — exactly the
way CI formats them. Verified with CI's exact check:

```
dart format --output=none --set-exit-if-changed lib test
Formatted 30 files (0 changed)
```

Changes are formatting only (whitespace + trailing commas). No logic, identifiers,
strings, numbers, or theme changed. `lib/` is otherwise untouched from v5.2.

New reference hashes (after applying, to verify):
- `lib/app/app.dart` SHA-256: c3a609b70a5b2fefe10d6b78aa083a016d4b20a3a73013935ba189a1c2b65e59
- `lib/app/app.dart` git blob: 97d6767b9043441e1863f6a7120e2f10e3f412f2

## How to apply (from F:\ZTECHX\AQUISET)

1. Download this zip and extract it OVER the project folder
   (the zip has `apps/mobile_flutter/lib` + `apps/mobile_flutter/test` at top level).
2. Run `git status --short` BEFORE committing. This time it MUST show the
   18 `.dart` files as modified (M). If it shows nothing, stop and say so —
   that is the proof the patch landed.
3. Then commit and push:
   `git add -A; git commit -m "Format code with Dart 3.13.7 (CI config)"; git push`
4. CI run #4 should then pass the format step, and `flutter analyze` +
   `flutter test` will run for the first time.

Do NOT tag v0.1.0 until CI is green.
