# AQUISET v5.3.2 — Real widget test (fixes `flutter analyze`)

## What CI said

Format is FIXED: CI run 5 (commit f0d9893) passed `dart format` with
`Formatted 31 files (0 changed)`. The next step, `flutter analyze`, failed
on ONE error:

```
error • The name 'MyApp' isn't a class • test/widget_test.dart:16:35
```

That file is the default counter-app test that `flutter create` generates in
CI. The app's root widget is not `MyApp`, it is `AquisetApp`, so the generated
test does not compile. The other 9 analyze findings are info-level only
(missing braces, one unnecessary import) and do not fail the build.

## What v5.3.2 is

One new file: `apps/mobile_flutter/test/widget_test.dart`. It is a real smoke
test that pumps the actual app (`AquisetApp`) with real services:
SharedPreferences is mocked in memory, and the native platform bridge
(RhythmPlatform) degrades to no-op in tests by design, so no native code is
needed. It asserts the app builds and the home shell renders (the Hydrate
nav label).

Because the file now exists in the repo, `flutter create` in CI leaves it
alone instead of generating the broken default test. The file is formatted
with Dart 3.13.7 (CI config), so the format check still passes
(`Formatted 31 files (0 changed)`).

No other file changed. No theme, logic, or dependency changed.

## How to apply (from F:\ZTECHX\AQUISET)

1. Download this zip and extract it to a temp folder, then copy the test
   folder over the project (same method as v5.3.1):
   `Expand-Archive` to `$env:TEMP\aq-v532`, then `Copy-Item` the
   `apps\mobile_flutter\test` folder over `F:\ZTECHX\AQUISET\apps\mobile_flutter\`.
2. Run `git status --short` BEFORE committing. It must show exactly one new
   file: `?? apps/mobile_flutter/test/widget_test.dart` (or `A` after add).
3. Then commit and push:
   `git add -A; git commit -m "Add real widget smoke test"; git push`
4. CI should then pass format, analyze, and test.

Do NOT tag v0.1.0 until CI is green.
